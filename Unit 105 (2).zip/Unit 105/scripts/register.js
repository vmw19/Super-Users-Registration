class User {
    constructor(firstName, lastName, email, password, age, address, cardNumber, phone, color) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.email = email;
        this.password = password;
        this.age = age;
        this.address = address;
        this.cardNumber = cardNumber;
        this.phone = phone;//##attention##
        this.color = color;
    }
}
function isValid(user){
    //return false when the user is not valid
    //return true when the user is  valid
    let valid=true;
    //we need to reset the orginal appearance of the inputs
    //by removing the error
    $("input").removeClass("input-error");
    if(user.email.length==0){
        valid=false;
        $('#txtEmail').addClass("input-error");
    
    }
    if(user.password.length==0){
        valid=false;
        $('#txtPassword').addClass("input-error");
        console.log("You need to add a password");
    }
    if(!valid){
    displayError("Missing data");
    }
    return valid;
}
function validatePass(){
    //get the values from the form
    let txtPass=$("#txtPassword");
    let password=txtPass.val();//getting the input from the DOM, so I only trave the DOM once

    if(password.length<6){//is password less than 6 characters?
        txtPass.css("border","2px solid red");//jquery function
        displayError("Error:password too short:(!");
    }else{
        txtPass.css("border","2px solid green");//jquery function
        hideError();
    }
}
//var vicky= new User('vicky', 'warren', 'alwaysvicky23@gmail.com', 'asdg','0000-0000-0000-0000');

//console.log(userList);
function displayError(msg){
        $("#alertError").removeClass("hide").text(msg);
        // setTimeout(function(){
        // $("#alertError").addClass("hide");
        // }, 2000);
            }
function hideError(){
    $("#alertError").addClass("hide");
}
function register(){
    let inputFirstName=$('#txtFirstname').val();
    let inputLastName=$('#txtLastname').val();
    let inputEmail=$('#txtEmail').val();
    let inputPassword=$('#txtPassword').val();
    let inputAge=jQuery("#txtAge").val();
    let inputAddress=$("#txtAddress").val();
    let inputCardNumber=$('#txtCardNumber').val();
    let inputPhone=$("#txtPhone").val();
    let inputColor=$("#txtColor").val();

    //create theUser
    let theUser=new User(inputFirstName,inputLastName, inputEmail, inputPassword, inputAge, inputAddress, inputCardNumber, inputPhone, inputColor)
    //validate the user**Extra HW
    if(isValid(theUser)){
        saveUser(theUser);
    //clear the inputs
    $("input").val("");
}
}
function login(){
    let inputEmail= $('#txtEmail').val();
    let inputPassword= $('#txtPassword').val();

    let users = readUsers();
    console.log(inputEmail, inputPassword);
    for(let i=0; i<users.length;i++)
    {
        console.log(users[i].email, users[i].password);
        if(users[i].email===inputEmail && users [i].password===inputPassword)
            {
                window.location='users.html';
            }
    }
}
function init(){
    console.log("Registration");
    //hook events
    $(".capture-form #txtPassword").change(validatePass);
}
window.onload=init;
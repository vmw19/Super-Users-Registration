const LS_KEY="users";
function saveUser(user){
    //load the old data
    let data=readUsers();
    //merge the old data
    data.push(user);
    //save
    //console.log(user);//this is the obj
    let val=JSON.stringify(data);//parse into a JSON string
    //console.log(val);//this is the string
    localStorage.setItem(LS_KEY,val);//send it into the localStorage
}
function readUsers(){
    let data=localStorage.getItem(LS_KEY);//get date from LS
    console.log(data);//JSON
    if(!data){//is not data?
        return[];//create an array
    }else{
        //we have data
        let list=JSON.parse(data);//obj
        // console.log(list);
        return list;
    }
}
function remove(index){
       //load the old data
       let data=readUsers();
       data.splice(index, 1);
       let val= JSON.stringify(data);//parse into a JSON string
       localStorage.setItem(LS_KEY,val);//send it into the localStorage
   }

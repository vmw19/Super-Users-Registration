function displayUsers(users){
    //travel the array
    $("#usersTable tbody").html("");
    let data="";
    //let row = "";
    for (let i = 0; i <users.length; i++) {
        data = data + createUser(users[i], i);
    }

        $("#usersTable tbody").html(data);

        //create the template
        // row += `
        // <tr id=${user.user}>
        //     <td> ${user.user[i].firstName}</td>
        //     <td> ${user.user[i].lastName}</td>
        //     <td> ${user.user[i].email}</td>
        //     <td> ${user.user[i].password}</td>
        //     <td> ${user.users[i].age}</td>
        //     <td>${user.user[i].address}</td>
        //     <td>${user.user[i].cardNumber}</td>
        //     <td>${user.user[i].phone}</td>
        //     <td>${user.user[i].color}</td>
        // </tr>
        // `;
    //get each users

    //display the user

    //append the user to the the table append() jquery
}
function createUser(user, index){
    return `<tr>
                <td>${user.firstName}</td>
                <td>${user.lastName}</td>
                <td>${user.email}</td>
                <td>${user.age}</td>
                
                <td>${user.address}</td>
                <td>${user.cardNumber}</td>
                <td>${user.phone}</td>
                <td>${user.color}</td>
                <td><input type='button' value='remove'onclick='removeUser(${index})'/></td>
            </tr>`;
}
function removeUser(index){
    remove(index);
    let users=readUsers();
    displayUsers(users);
}
function init(){
    console.log("Listing users");
    let users=readUsers();
    displayUsers(users);
}
window.onload=init;
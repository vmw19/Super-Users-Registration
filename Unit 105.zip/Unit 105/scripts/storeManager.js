const LS_KEY="users";
function saveUser(user){
    //console.log(user);//this is the obj
    let val=JSON.stringify(user);//parse into a JSON string
    //console.log(val);//this is the string
    localStorage.setItem(LS_KEY,val);//send it into the localStorage
}